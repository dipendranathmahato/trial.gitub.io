/* ==========================================================
   DIPENDRANATHMAHATO.COM — EASY-UPDATE DATA
   Most routine semester/profile updates can be made here.
   ========================================================== */
window.SITE_DATA = {
  profile: {
    name: "Dipendranath Mahato",
    shortName: "DIPEN",
    role: "Lecturer in Mathematics",
    institution: "The University of Texas Rio Grande Valley",
    institutionShort: "UTRGV",
    location: "Edinburg, Texas, USA",
    // Add your UTRGV office/email when you want them shown site-wide.
    office: "",
    institutionalEmail: "",
    personalEmail: "dipendranathmahato13@gmail.com"
  },

  teaching: {
    currentTerm: "Fall 2026",
    officeHours: [
      "Tuesday & Thursday · 3:30–5:30 PM",
      "Friday · 12:00–2:00 PM"
    ],
    courses: [
      {
        code: "MATH 2412",
        title: "Precalculus",
        section: "804",
        term: "Fall 2026",
        status: "Current",
        description: "Course information, review material, practice tests, and class resources.",
        links: [
          { label: "Course materials", url: "", icon: "fa-folder-open" },
          { label: "Brightspace", url: "", icon: "fa-arrow-up-right-from-square" }
        ]
      },
      {
        code: "MATH 2412",
        title: "Precalculus",
        section: "06",
        term: "Fall 2026",
        status: "Current",
        description: "Course information, review material, practice tests, and class resources.",
        links: [
          { label: "Course materials", url: "", icon: "fa-folder-open" },
          { label: "Brightspace", url: "", icon: "fa-arrow-up-right-from-square" }
        ]
      },
      {
        code: "MATH 1314",
        title: "College Algebra",
        section: "204",
        term: "Fall 2026",
        status: "Current",
        description: "Course information, announcements, and supplementary resources.",
        links: [
          { label: "Course materials", url: "", icon: "fa-folder-open" },
          { label: "Brightspace", url: "", icon: "fa-arrow-up-right-from-square" }
        ]
      }
    ]
  },

  documents: {
    // Example: { label: "MATH 2412 Practice Test 1", url: "https://...", type: "Box" }
    external: []
  }
};
