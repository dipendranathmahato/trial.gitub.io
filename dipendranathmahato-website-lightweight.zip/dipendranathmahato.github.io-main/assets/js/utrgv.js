(function () {
  const data = window.SITE_DATA;
  if (!data) return;

  const $ = (id) => document.getElementById(id);
  const setText = (id, value) => { const el = $(id); if (el && value) el.textContent = value; };

  setText('currentTerm', data.teaching.currentTerm);
  setText('currentLocation', data.profile.location);

  const courseGrid = $('utrgvCourseGrid');
  if (courseGrid) {
    courseGrid.innerHTML = data.teaching.courses.map(course => {
      const links = (course.links || []).map(link => link.url
        ? `<a class="course-action" href="${link.url}" target="_blank" rel="noopener"><i class="fa-solid ${link.icon || 'fa-link'}"></i>${link.label}</a>`
        : `<span class="course-action is-pending" title="Add this URL in assets/js/site-data.js"><i class="fa-solid ${link.icon || 'fa-link'}"></i>${link.label}<small>Add link</small></span>`
      ).join('');
      return `<article class="utrgv-course-card">
        <div class="course-card-top"><span class="course-code">${course.code}</span><span class="current-badge">${course.status}</span></div>
        <h2>${course.title}</h2>
        <p class="course-meta">Section ${course.section} · ${course.term}</p>
        <p>${course.description}</p>
        <div class="course-actions">${links}</div>
      </article>`;
    }).join('');
  }

  const officeHours = $('officeHoursList');
  if (officeHours) {
    officeHours.innerHTML = data.teaching.officeHours.map(item => `<li><i class="fa-regular fa-clock"></i><span>${item}</span></li>`).join('');
  }

  const docs = $('externalDocs');
  if (docs) {
    if (!data.documents.external.length) {
      docs.innerHTML = `<div class="empty-state"><i class="fa-regular fa-folder-open"></i><div><strong>External course library ready</strong><p>Add Box or Dropbox share links in <code>assets/js/site-data.js</code>; they will appear here automatically.</p></div></div>`;
    } else {
      docs.innerHTML = data.documents.external.map(doc => `<a class="resource-row" href="${doc.url}" target="_blank" rel="noopener"><span><i class="fa-regular fa-file-pdf"></i>${doc.label}</span><small>${doc.type || 'External'} <i class="fa-solid fa-arrow-up-right-from-square"></i></small></a>`).join('');
    }
  }
})();
